<?php
include_once 'db.inc.php';//include database creds
?>
	<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css"/>
		<title>Aptaris Index Page</title>
		<style>
			header{
				height: 115px;	
			}
		</style>
	</head>
	
	<body>
		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="../php/new_taskLibrary.php">Add Task Library</a>
					<a href="../php/delete_taskLibrary.php">Delete Task Library</a>
					<a href="../php/add_template.php">Add Task Template to Task Library</a>
					<a href="../php/list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
			<?php
				if($_SERVER['REQUEST_METHOD'] == 'POST'
				&& $_POST['submit'] == 'Select Another Template from Library')
				{
					$db = new PDO(DB_INFO, DB_USER, DB_PASS);
					$tempValue = $_POST['template'];
					
					$sql = "SELECT `Template Code`, `Task Template Name`, `Task Template Description`,
							`Completed Before End Date`
							FROM TaskTemplate
							WHERE `Template Code` = ?";
					
					$stmt = $db->prepare($sql);
					$stmt->execute(array($tempValue));
					if (!$stmt){
						die('No query results'.mysql_error());
					}	
				}
			?>
				<div>
					<?php
					while($r = $stmt->fetch()){
						echo $r['Task Template Name'];	
					?><br />
					<?php echo $r['Template Code'];?><br />
					<?php echo $r['Task Template Description'];?><br />
					<?php echo $r['Completed Before End Date'];}?><br />
				</div>
				<div class="form_content">
					<form action="insert_edit.inc.php" method="post">
						<h2>Edit Content</h2>
					<div>
						
						<label for="temp_name">Edit Task Template Name</label><br />
						<input type="text" name="temp_name" />
					</div>
					<br />
					<div>
						<label for="temp_desc">Edit Task Template Description</label><br />
						<textarea cols="30" name="temp_desc" rows="4" maxlength="140"></textarea>
					</div>
					<br />
					<div>
						<label for="end_date">Edit Completed Before End Date</label><br />
						<input type="number" name="end_date" maxlength="3"/>
					</div>
					<br />
					<br />
					<div>
						<input type="submit" name="submit" value="Edit Task Template"/>
						<input type="reset" name="reset" value="Clear Fields" />
					</div>
					</form>
				</div>
				<div class="form_content">
					<h2>Delete Task Template</h2>
					<form action="delete_edit.inc.php" method="post">
						<input type="submit" name="submit" value="Delete Task Template"/>
					</form>
				</div>
		</div>		
</html>