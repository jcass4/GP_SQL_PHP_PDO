<?php
require('dbinfo.inc.php');
require('ui_display_add_tl.inc');
	
insertTaskLibrary();

function insertTaskLibrary()
{
		connect_and_select_db(DB_SERVER, DB_UN, DB_PWD, DB_NAME);
        $name = $_POST['taskname'];
        $description = $_POST['description'];

        $insertStmt = "INSERT INTO `TaskLibrary`
        			  (`Name`, `Task Library Description`)
        			  VALUES ('$name', '$description')";

        $result = mysql_query($insertStmt);
		echo $result;
        $message = "";

        if (!$result)
        {
          echo "Error in inserting Task Library: $name ".mysql_error();
        }
        else
        {
	       $message = "Data For Task Library ".$name." Entered Successfully";
         ui_display_task_library_insertion_result($message); 

        }


}
function connect_and_select_db($server, $username, $pwd, $dbname)
{	
        $conn = mysql_connect($server, $username, $pwd);

        if (!$conn) {
            echo "Unable to connect to DB: " . mysql_error();
            exit;
        }


        $dbh = mysql_select_db($dbname);
        if (!$dbh){
                echo "Unable to select ".$dbname.": " . mysql_error();
                exit;
        }
}

