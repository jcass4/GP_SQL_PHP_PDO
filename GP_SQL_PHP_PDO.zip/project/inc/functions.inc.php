<?php
function retrieveLibrary($db){
	//Retrieves Libraries from the database
	
	$sql = "SELECT `Library ID`, `Name`
			FROM TaskLibrary";
	$stmt = $db->query($sql);
	if (!$sql){
		die('No query results'.mysql_error());
	}

	return $stmt;
}

function retrieveTaskTemplates($db){
	//Retrieves Task Templates from the database
	
	$sql = "SELECT `Template Code`,`Task Template Name`, `Task Template Description`,`Completed Before End Date`
			FROM TaskTemplate, TaskLibraryToTaskTemplate
			WHERE (TaskLibrary.`Library ID` = TaskLibraryToTaskTemplate.`Library ID`) &&";
	$stmt = $db->query($sql);
	if (!$sql){
		die('No query results'.mysql_error());
	}

	return $stmt;
}


function retrieveTaskLibraryTemplates($db){
	//Retrieves Task Templates from the database
	
	$sql = "SELECT TaskTemplate.`Template Code`, TaskTemplate.`Task Template Name`, TaskTemplate.`Task Template Description`,TaskTemplate.`Completed Before End Date`
                            FROM TaskTemplate, TaskLibraryToTaskTemplate
                            WHERE 
                                TaskLibraryToTaskTemplate.`Library ID`=".$library." and
                                TaskLibraryToTaskTemplate.`Template Code` = TaskTemplate.`Template Code`";
    
	$stmt = $db->query($sql);
	if (!$sql){
		die('No query results'.mysql_error());
	}

	return $stmt;
}
?>