<?php
//For mysql connections
define('DB_SERVER', 'csdb.brockport.edu');
define('DB_UN', 'jcass4');
define('DB_PWD', 'xxxx');
define('DB_NAME', 'Team_Pane');
?>
