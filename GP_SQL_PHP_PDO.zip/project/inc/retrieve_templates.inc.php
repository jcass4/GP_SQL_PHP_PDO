<?php
	include_once 'db.inc.php';//include database creds
	?>
	<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css"/>
		<title>Aptaris Index Page</title>
		<style>
			header{
				height: 115px;	
			}
		</style>
	</head>
	
	<body>
		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="../php/new_taskLibrary.php">Add Task Library</a>
					<a href="../php/delete_taskLibrary.php">Delete Task Library</a>
					<a href="../php/add_template.php">Add Task Template to Task Library</a>
					<a href="../php/list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST'
				&& $_POST['submit'] == 'Get Templates from Library')
				{
				

			
			//open database session
			$db = new PDO(DB_INFO, DB_USER, DB_PASS);
			
			/*
			 * Collect Form Information
			 */
			$templateLibrary = $_POST['library'];
			
			$sql = "SELECT `TaskTemplate`.`Template Code`, `TaskTemplate`.`Task Template Name`, 
					`TaskTemplate`.`Task Template Description`, `TaskTemplate`.`Completed Before End Date`
					FROM TaskTemplate, TaskLibraryToTaskTemplate
					WHERE ((`TaskLibraryToTaskTemplate`.`Library ID` = ?) 
					AND (`TaskLibraryToTaskTemplate`.`Template Code` = TaskTemplate.`Template Code`))"; 
			$stmt = $db->prepare($sql);
			$stmt->execute(array($templateLibrary));
			if (!$stmt){
				die('No query results'.mysql_error());
			}
			
			
}	
?>
			<div class="form_content">
			<form action="revolve_select.inc.php" method="post">
			<label for="template">Select a Task Template</label><br/>
			<select name="template">
				<option selected disabled hidden value="">Select an available Template</option>
				<?php 
				while($r = $stmt->fetch()){
				?>
					<option value="<?php echo $r['Template Code']; ?>">
						<?php echo $r['Task Template Name']; ?>
					</option>
				<?php 
				}//end while loop
				?>
			</select>
				<br /><br />
			<input type="submit" name="submit" value="Select Another Template from Library" />
			<input type="reset" name="reset" value="Reset" />
			</form>
			
			</div>		
	</div>
	
</div>		
</html>