<?php	
			
			if($_SERVER['REQUEST_METHOD'] == 'POST'
				&& $_POST['submit'] == 'Delete Task Library'
				&& !empty($_POST['delete_tl'])){
				
			//include database creds
			include_once 'db.inc.php';
			
			//open database session
			$db = new PDO(DB_INFO, DB_USER, DB_PASS);
			
			/*
			 * Collect Form Information
			 */
			$deleteID = $_POST['delete_tl'];
				
			//Delete query
			$sql = "DELETE FROM `TaskLibrary`
					WHERE `Library ID` = ?";
			
			//prepare(clean) $sql statement
			$stmt = $db->prepare($sql);
			
			//execute add with form values
			$stmt->execute(array($deleteID));
			
			/*
			 * Return the template code from the last inserted template
			 */
			
			//tell the user that their data was entered
			echo "The task library", $templateName, " was deleted form the project group";
			echo "<br/>";
			echo '<a href="../index.html">Back to Home Page</a>';
			
		}
		else{
			echo '<a href="../php/delete_taskLibrary.php">Please go back and enter valid information</a>';	
		}
			
?>
