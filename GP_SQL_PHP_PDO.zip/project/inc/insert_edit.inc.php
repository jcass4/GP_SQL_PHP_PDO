<?php
include_once 'db.inc.php';//include database creds
include_once 'revolve_select.inc.php';
?>
	<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css"/>
		<title>Aptaris Index Page</title>
		<style>
			header{
				height: 115px;	
			}
		</style>
	</head>
	
	<body>
		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="../php/new_taskLibrary.php">Add Task Library</a>
					<a href="../php/delete_taskLibrary.php">Delete Task Library</a>
					<a href="../php/add_template.php">Add Task Template to Task Library</a>
					<a href="../php/list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
			<?php
				if($_SERVER['REQUEST_METHOD'] == 'POST'
				&& $_POST['submit'] == 'Edit Task Template')
				{
					$db = new PDO(DB_INFO, DB_USER, DB_PASS);
					$tempCode = $stmt->fetch();
					$tempCode = $tempCode['Template Code'];
					$tempName = $_POST['temp_name'];
					$tempDesc = $_POST['temp_desc'];
					$compDate = $_POST['end_date'];
					
					$sql = "UPDATE TaskTemplate 
							SET `Template Name` = ?,
							SET `Task Template Description` = ?,
							SET `Completed Before End Date` =?
							WHERE `TaskTemplate`.`Template Code` = ?";
					
					$stmt = $db->prepare($sql);
					$stmt->execute(array($tempName, $tempDesc, $compDate, $tempCode));
					
					if (!$stmt){
						die('No query results'.mysql_error());
					}
					else{
						echo "Data Updated";
					}	
				}
			?>
				
		</div>		
</html>