<?php
//For PDO (PHP Database Object) connections
define('DB_INFO', 'mysql:host=csdb.brockport.edu;dbname=Team_Pane');
define('DB_USER', 'jcass4');
define('DB_PASS', 'xxxx');

?>
