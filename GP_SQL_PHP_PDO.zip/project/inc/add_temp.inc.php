<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css"/>
		<title>Aptaris Index Page</title>
		<style>
			header{
				height: 115px;	
			}
		</style>
	</head>
	
	<body>
		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="../php/new_taskLibrary.php">Add Task Library</a>
					<a href="../php/delete_taskLibrary.php">Delete Task Library</a>
					<a href="../php/add_template.php">Add Task Template to Task Library</a>
					<a href="../php/list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
			<p>
<?php
			//Matthew Panebianco Task 3
			
			
			if($_SERVER['REQUEST_METHOD'] == 'POST'
				&& $_POST['submit'] == 'Add Template to Task Library'
				&& !empty($_POST['templateName'])
				&& !empty($_POST['templateDescription'])
				&& !empty($_POST['templateEndDate'])
				&& !empty($_POST['library'])){
				
			//include database creds
			include_once 'db.inc.php';
			
			//open database session
			$db = new PDO(DB_INFO, DB_USER, DB_PASS);
			
			/*
			 * Collect Form Information
			 */
			$templateLibrary = $_POST['library'];
			$templateName = $_POST['templateName'];	
			$templateDescription = $_POST['templateDescription'];	
			$templateEndDate = $_POST['templateEndDate'];	
				
			//Insert query
			$sql = "INSERT INTO `TaskTemplate`
			(`Task Template Name`, `Task Template Description`, 
			`Completed Before End Date`) VALUES (?,?,?)";
			
			//prepare(clean) $sql statement
			$stmt = $db->prepare($sql);
			
			//execute add with form values
			$stmt->execute(array($templateName, $templateDescription, $templateEndDate));
			
			/*
			 * Return the template code from the last inserted template
			 */
			$tempCode = $db->lastInsertId();
			
			/*
			 * Add selected id & temp code to TL2TT
			 */
			
			//Grab selected TaskLibrary name
			$sql_for_tl = "SELECT `Name`
						   FROM `TaskLibrary`
						   WHERE `Name` = ?";
			
			//prepare (clean) $sql_for_tl
			$stmt_for_tl = $db->prepare($sql_for_tl);
			
			//execute select
			$stmt_for_tl->execute(array($templateLibrary));
			
			//Insert query
			$sql_for_tltt = "INSERT INTO `TaskLibraryToTaskTemplate`
							(`Library ID`, `Template Code`)
							VALUES (?, ?)";
			
			//prepare (clean) $sql_for_tltt
			$stmt_for_tltt = $db->prepare($sql_for_tltt);
			
			//excute add with form values
			$stmt_for_tltt->execute(array($templateLibrary, $tempCode));
			
			//tell the user that their data was entered
			echo "The task template ", $templateName, ", due ", $templateEndDate,
				" days before the completion of the project was added to the library ",
				$stmt_for_tl->fetch();
			echo "<br/>";
			echo '<a href="../index.html">Back to Home Page</a>';
			
		}
		else{
			echo '<a href="../php/add_template.php">Please go back and enter valid information</a>';	
		}
			
?>

			</p>
		</div>
	</body>
</html>