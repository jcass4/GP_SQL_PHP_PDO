<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css" />
		<title>Aptaris Index Page</title>
		<style>
			header{
				height: 115px;	
			}
		</style>
	</head>
	
	<body>
		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="../php/new_taskLibrary.php">Add Task Library</a>
					<a href="../php/delete_taskLibrary.php">Delete Task Library</a>
					<a href="../php/add_template.php">Add Task Template to Task Library</a>
					<a href="../php/list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
				<div class="form_content">
					<form action="../inc/insert_tl.php" method="post">
					<div>
						<label for="taskname">New Task Library Name</label><br />
						<input name="taskname" type="text" size="50" />
					</div>
					<div>
						<label for="description">Description</label><br />
						<input name="description" type="text" size="50" />
					</div>
					<br />
					<div>
						<input type="submit" value="Submit New Task Library" />
						<input type="reset" value="reset" />
					</div>
					</form>
				</div>
		</div>
	</body>
</html>