<?php
	// Matthew Panebianco Task 3
	/*
	 * Include the necessary files
	 */
	include_once '../inc/functions.inc.php';
	include_once '../inc/db.inc.php';
	
	//Open a database connection
	
	try{
		$db = new PDO(DB_INFO, DB_USER, DB_PASS);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
		die();
	}
	
	$l = retrieveLibrary($db);

?>

<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css" />
		<title>Add Template to Library</title>
		<style>
			header{
				height: 115px;
			}
		</style>
	</head>

		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="new_taskLibrary.php">Add Task Library</a>
					<a href="delete_taskLibrary.php">Delete Task Library</a>
					<a href="add_template.php">Add Task Template to Task Library</a>
					<a href="list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
		<h1>Add Template To Library</h1>
		<div class="form_content">
		<form method="post" action="../inc/add_temp.inc.php">
		<div id ="library">
			<label for="library">Select a Task Library</label><br/>
			<select name="library">
				<option selected disabled hidden value="">Select an available library</option>
				<?php 
				while($r = $l->fetch()){
				?>
					<option value="<?php echo $r['Library ID']; ?>">
						<?php echo $r['Name']; ?>
					</option>
				<?php 
				}//end while loop
				?>
			</select>
		</div>
			
		<div>
			<label for="templateName">Template Name<br />
			<input name="templateName" type="text" length="20" maxlength="35" /></label>
		</div>
		<div>
			<label for="templateEndDate">Days Till End Date<br /> <input name="templateEndDate" type="number" maxlength="3" /></label>
		</div>
			<br />
		
		<div>
			<label for="templateDescription">Template Description<br /><textarea cols="30" name="templateDescription" rows="4" maxlength="140">Max Length is 140 characters</textarea></label>
		</div>
		
			<br />
		<div>
			<input type="submit" name="submit" value="Add Template to Task Library" />
			<input type="reset" name="reset" value="Clear Fields" />
		</div>
		</form>
	</div>
	
</div>		
</html>