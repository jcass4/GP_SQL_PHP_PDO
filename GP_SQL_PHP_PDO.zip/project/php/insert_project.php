<?php
require('project_database.inc');

//inserts new project
//calls function to generate project code


//main control logic
insert_project();

function insert_project()
{

	// Connect to the 'test' database 
        // The parameters are defined in the teach_cn.inc file
        // These are global constants
	connect_and_select_db(DB_SERVER, DB_UN, DB_PWD,DB_NAME);

	// Get the information entered into the webpage by the user
        // These are available in the super global variable $_POST
	// This is actually an associative array, indexed by a string
	$projectName = $_POST['projectName'];
	$description = $_POST['description'];
	$category = $_POST['category'];
	$duedate = $_POST['duedate'];
        $currentdate = $_POST['currentdate'];
       // $projectCode = info from other method in other php doc
       generate_project_code($category, $currentdate);
        
	// Create a String consisting of the SQL command. Remember that
        // . is the concatenation operator. $varname within double quotes
 	// will be evaluated by PHP
	$insertStmt = "insert Project (Project Code, Name, Project Description, Category Code, 
		       End Date) values ( '$projectCode', '$projectName', '$description',
                      '$category', '$duedate', '$currentdate')";

	//Execute the query. The result will just be true or false
	$result = mysql_query($insertStmt);

	$message = "";

	if (!$result) 
	{
  	  $message = "Error in inserting Project: $projectName ". mysql_error();
	}
	else
	{
	  $message = "Data for Project: $projectName inserted successfully.";
	  
	}

	ui_show_project_insert_result($message);
			   
}

function connect_and_select_db($server, $username, $pwd, $dbname)
{
	// Connect to db server
	$conn = mysql_connect($server, $username, $pwd);

	if (!$conn) {
	    echo "Unable to connect to DB: " . mysql_error();
    	    exit;
	}

	// Select the database	
	$dbh = mysql_select_db($dbname);
	if (!$dbh){
    		echo "Unable to select ".$dbname.": " . mysql_error();
		exit;
	}
}
function ui_show_project_insert_result($message)
{
  //----------------------------------------------------------
  // Start the html page
  echo "<HTML>";
  echo "<HEAD>";
  echo "</HEAD>";
  echo "<BODY>";

  // If the message is non-null and not an empty string print it
  // message contains the lastname and firstname
  if ($message)
  {
    if ($message != "")
       {
	 echo '<center><font color="blue">'.$message.'</font></center><br />';
       }
  }

//finish up the html code, and put the return button to go back to main menu
echo <<<UPTOEND
  <BR/><BR/>
  <center>
  <input type="button" value="Return to Main Menu" 
	onClick="window.location='add_project_ui.html'"/>
  </center>
UPTOEND;

 echo "</BODY>";
 echo "</HTML>";
}

function generate_project_code($category, $currentdate)
{
    //formula is category code (two letters), the current date, and a suffix consisting of a single letter starting at A
    
    /*	
    	Match a concatenation of the current category and date values
    	with any current project codes currently within the database
		(category + current date + *any characters)
		
		pull the non date and non category variable sections of the
		matched project codes and put them in an array
    	Have an array of suffixes (all 26 letters), and have the the 
    	loop check to find the first open suffix character by comparing
    	the last value of the existing project code to the current characters
    	in the array. If there doesnt exist one with that suffix, add that
    	suffix value to the project code to be inserted and then send the 
    	form info to the database
    */
    $suffix = "A";
   $projectCode = $category + $currentdate + $suffix;
    //check for existing matching category, then date, then for suffix that doesn't exsist
}

?>
