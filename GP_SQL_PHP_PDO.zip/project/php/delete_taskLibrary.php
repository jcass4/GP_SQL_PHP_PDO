<?php
	include_once '../inc/functions.inc.php';
	include_once '../inc/db.inc.php';
	
	//Open a database connection
	
	try{
		$db = new PDO(DB_INFO, DB_USER, DB_PASS);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
		die();
	}
	
	$l = retrieveLibrary($db);

?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/main.css"/>
		<title>Aptaris Index Page</title>
		<style>
			header{
				height: 115px;	
			}
		</style>
	</head>
	
	<body>
		<div id="main">
			<header>
				<h1>Aptaris Project Management Index Page</h1>
				<div id="nav">
					<a href="new_taskLibrary.php">Add Task Library</a>
					<a href="delete_taskLibrary.php">Delete Task Library</a>
					<a href="add_template.php">Add Task Template to Task Library</a>
					<a href="list_task_templates.php">List Task Templates from Selected Library</a>
				</div>
			</header>
			<div class="form_content">
				<form action="../inc/delete_tl.php" method="post">
					<div>
						<label for="delete_tl">Select a Task Library to Delete</label> <br />
						<select name="delete_tl" >
							<option selected disabled hidden>Select a Library</option>
							<?php 
								while($r = $l->fetch()){
							?>
								<option value="<?php echo $r['Library ID']; ?>">
								<?php echo $r['Name']; ?>
								</option>
								<?php 
								}//end while loop
								?>
 						</select>
					</div>
						<br />
					<div>
						<input type="submit" name="submit" value="Delete Task Library"/>
						<input type="reset" value="Unselect Library" />
					</div>
				</form>
			</div>
		</div>
	</body>
</html>
