<?php
    include_once '../inc/db.inc.php';
    include_once '../inc/functions.inc.php';
    ?>

<html>
    <head>
        <title>List All Task Templates</title>
    </head>
    <body>
        <h2>List All Task Templates</h2>
       <?php
            try{
		$db = new PDO(DB_INFO, DB_USER, DB_PASS);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            catch(PDOException $e){
                    echo $e->getMessage();
                    die();
            }
	
            $l = retrieveTaskTemplates($db);
            ?>
        <table>
            <tr>
                <th>Template Name</th>
                <th>Template Description</th>
                <th>Completed Before End Date</th>
            </tr>
            <?php
            while($r = $l->fetch()){
                echo 
                "<tr>
                  <td>".$r['Task Template Name']."</td>".
                  "<td>".$r['Task Template Description']."</td>".
                  "<td>".$r['Completed Before End Date']."</td>".
                 "</tr>";
                 
            }
            ?>
        </table>
        <form method="post" action="list_task_templates.php">
            <h2>Task Libraries </h2>
            <?php
                $l = retrieveLibrary($db);
		while($r = $l->fetch()){
                    echo "<input type='radio' name='library' value='".$r['Library ID']."' >".$r['Name']."<br>";
                }
            ?>
            <input type="submit" value="Submit">
            
        </form>

    </body>
</html>
