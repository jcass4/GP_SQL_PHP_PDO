<?php

session_start(); 
 
//Function definition- delete ONLY ONE AT A TIME
function delete_task_template()
{ 
	
	// Connect to db 
	connect_and_select_db(DB_SERVER, DB_UN, DB_PWD,
		DB_NAME);

	// Get all the parameters from the http POST request
	// $_POST is the php super-global that contains the 
	// data in a post request
	
	
		//Get the template code of the selected template indicated by a radio button
				
			$current_code = $_POST['selected'];
		
			$sql = "DELETE FROM TaskTemplate
                         WHERE Template Code = '$current_code'";         		

			$error_message = "Could not successfully delete ".
               		" task template from DB ($sql) ";

			$result = execute_SQL_query($sql, $error_message);	
		
	
		ui_close_del_task_templates("Task template was deleted
			successfully");
	
	
}

function edit_task_template()
{
	// Connect to db 
	connect_and_select_db(DB_SERVER, DB_UN, DB_PWD,
		DB_NAME);
	// Get the parameters from the user 
	//if one remains empty, do not update
	$new_name = $_POST['newname'];
	$new_desc = $_POST['newdesc'];
	$new_days = $_POST['newdays'];
	//get template code of selected template from form
	$template_code = $_POST['selected_code'];
	if ($new_name != "")
	{
		$sql = "UPDATE TaskTemplate SET Task Template Name='".$new_name.
		"' WHERE Template Code='".$template_code."'";
		$result = execute_SQL_query_with_no_error_report
			($sql);
		if ($result)
		{
			//call listing page again
			//("Template name successfully changed", "OK");
		}
		else
		{
			//if error, invalid input? 
			//("Database access error in changing template name.", "error");
		}
	}
	if ($new_desc != "")
	{
		$sql = "UPDATE TaskTemplate SET Task Template Description='".$new_desc.
		"' WHERE Template Code='".$template_code."'";

		$result = execute_SQL_query_with_no_error_report
			($sql);

		if ($result)
		{
			//call listing page again
			//("Template description successfully changed", "OK");
		}
		else
		{
			//if error, invalid input? 
			//("Database access error in changing template description.", "error");
		}
	}
if ($new_days != "")
	{
		$sql = "UPDATE TaskTemplate SET Completed Before End Date='".$new_days.
		"' WHERE Template Code='".$template_code."'";

		$result = execute_SQL_query_with_no_error_report
			($sql);

		if ($result)
		{
			//call listing page again
			//("Template number of days until completion successfully changed", "OK");
		}
		else
		{
			//if error, invalid input?
			//("Database access error in changing template number of days until completion.", "error");
		}
	}
	}
?>